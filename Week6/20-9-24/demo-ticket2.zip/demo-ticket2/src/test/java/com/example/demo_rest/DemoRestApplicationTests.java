package com.example.demo_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
