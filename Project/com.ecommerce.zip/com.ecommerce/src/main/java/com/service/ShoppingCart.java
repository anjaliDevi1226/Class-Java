package com.service;

import com.app.Product;


import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class ShoppingCart {
     
    private List<CartItem> cartItems = new ArrayList<>();

  
    public void addToCart(CartItem cartItem, int quantity) {
        boolean itemExists = false;
        for (CartItem existingItem : cartItems) {
            if (existingItem.getProduct().getProductId() == cartItem.getProduct().getProductId()) {
               
                existingItem.setQuantity(existingItem.getQuantity() + quantity);
                itemExists = true;
                break;
            }
        }
        if (!itemExists) {
           
            cartItem.setQuantity(quantity);
            cartItems.add(cartItem);
        }
    }

    
    public void viewCart() {
        System.out.println("Shopping Cart:");
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
        	 System.out.println("Product Name        Price      Quantity  ");
             System.out.println("-----------------------------------------");
            for (CartItem cartItem : cartItems) {
                Product product = cartItem.getProduct();
               
                System.out.print(product.getProductName());
                for (int i = product.getProductName().length(); i < 20; i++) {
                    System.out.print(" ");
                }
                System.out.print("$" +product.getPrice());
                for (int i = String.valueOf(product.getPrice()).length(); i < 11; i++) {
                    System.out.print(" ");
                }
               
                    System.out.println(cartItem.getQuantity());
                
            }
        }
    }

   
   
    public void removeFromCart(int productId, int quantity) {
        Iterator<CartItem> iterator = cartItems.iterator();
        while (iterator.hasNext()) {
            CartItem cartItem = iterator.next();
            Product product = cartItem.getProduct();

            if (product.getProductId() == productId) {
                int currentQuantity = cartItem.getQuantity();
                if (currentQuantity <= quantity) {
                    iterator.remove(); 
                } else {
                    cartItem.setQuantity(currentQuantity - quantity); 
                }
                break;
            }
        }
    }

    
    
    public void checkout() {
    	    if (cartItems.isEmpty()) {
    	        System.out.println("Your cart is empty. Cannot proceed with checkout.");
    	        return;
    	    }

    	    double total = 0;
    	    
    	    
    	    System.out.println("Checkout Summary:");
    	    
    	    System.out.println("Product Name        Price      Quantity  Total");
            System.out.println("-----------------------------------------------");
    	    for (CartItem cartItem : cartItems) {
    	        Product product = cartItem.getProduct();
    	        double itemTotalPrice = cartItem.getTotalPrice();
    	        total += itemTotalPrice;
    	      
    	    
    	    System.out.print(product.getProductName());
            for (int i = product.getProductName().length(); i < 20; i++) {
                System.out.print(" ");
            }
            System.out.print(product.getPrice());
            for (int i = String.valueOf(product.getPrice()).length(); i < 11; i++) {
                System.out.print(" ");
            }
            System.out.print(cartItem.getQuantity());
            for (int i = String.valueOf(cartItem.getQuantity()).length(); i < 10; i++) {
                System.out.print(" ");
            }
            System.out.println("$" +itemTotalPrice);
        }

        
        System.out.println("-----------------------------------------------");
        System.out.print("Total amount: ");
        for (int i = 1; i < 28; i++) {
            System.out.print(" ");
        }
    	    System.out.println("$" + total);
    	    
    	    
    	    cartItems.clear();
    	    System.out.println("Thank you for your purchase!");
    	}

}
