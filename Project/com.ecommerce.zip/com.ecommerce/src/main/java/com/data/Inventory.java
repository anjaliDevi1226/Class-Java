package com.data;

import com.app.Product;

import java.util.List;

public interface Inventory {
    List<Product> getProducts();     
    Product findProductById(int productId); 
    void searchProduct(String partialProdName); 
}
