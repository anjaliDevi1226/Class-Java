package com.data;

import com.app.Product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Inventoryclass implements Inventory {
    private Connection connection;

    public Inventoryclass() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1:3306/ecommerce",
                "root", "pass@word1");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM products")) {

            while (resultSet.next()) {
                Product product = new Product(
                    resultSet.getInt("product_id"),
                    resultSet.getString("product_name"),
                    resultSet.getString("category"),
                    resultSet.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public Product findProductById(int productId) {
        Product product = null;
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM products WHERE product_id = ?")) {
            ps.setInt(1, productId);
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                product = new Product(
                    resultSet.getInt("product_id"),
                    resultSet.getString("product_name"),
                    resultSet.getString("category"),
                    resultSet.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    @Override
    public void searchProduct(String partialProdName) {
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM products WHERE product_name LIKE ?")) {
            ps.setString(1, "%" + partialProdName + "%");
            ResultSet resultSet = ps.executeQuery();

            boolean productFound = false;
            while (resultSet.next()) {
                System.out.println("Product found: " + resultSet.getString("product_name") + " - $" + resultSet.getDouble("price"));
                productFound = true;
            }

            if (!productFound) {
                System.out.println("No products found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
