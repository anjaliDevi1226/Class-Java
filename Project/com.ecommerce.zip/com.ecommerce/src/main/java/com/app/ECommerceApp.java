package com.app;

import com.data.Inventory;
import com.data.Inventoryclass;
import com.service.CartItem;
import com.service.ShoppingCart;

import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;

public class ECommerceApp {
    public static void main(String[] args) {
        Inventory inventory = new Inventoryclass();  
        ShoppingCart cart = new ShoppingCart();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            try {
                System.out.println("Menu:");
                System.out.println("1. Search for Products");
                System.out.println("2. Add Product to Cart");
                System.out.println("3. View Shopping Cart");
                System.out.println("4. Checkout");
                System.out.println("5. Display Available Products");
                System.out.println("6. Remove Product from Cart");
                System.out.println("7. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter product name: ");
                        scanner.nextLine(); 
                        String productName = scanner.nextLine();
                        inventory.searchProduct(productName);
                        break;

                    case 2:
                        System.out.print("Enter Product ID: ");
                        int productId = scanner.nextInt();
                        System.out.print("Enter Quantity: ");
                        int quantity = scanner.nextInt();
                        Product product = inventory.findProductById(productId);
                        if (product != null) {
                            cart.addToCart(new CartItem(product, quantity), quantity);
                            System.out.println("Product added to cart.");
                        } else {
                            System.out.println("Product not found.");
                        }
                        break;

                    case 3:
                        cart.viewCart();
                        break;

                    case 4:
                        cart.checkout();
                        break;

                    case 5:
                    	 System.out.println("Available Products:");
                         List<Product> products = inventory.getProducts();
                         if (products.isEmpty()) {
                             System.out.println("No products available.");
                         } else {
                        	 System.out.println("Product Name         Product ID        Price");
                             System.out.println("-----------------------------------------------");
                         
                             for (Product product1 : products) {
                                 System.out.print( product1.getProductName() );
                                 for (int i = product1.getProductName().length(); i < 21; i++) {
                                     System.out.print(" ");
                                 }
                                 System.out.print( product1.getProductId() );
                                 for (int i = String.valueOf(product1.getProductId()).length(); i <18; i++) {
                                     System.out.print(" ");
                                 }
                                 
                                     System.out.print("$" +product1.getPrice());
                                     System.out.println();
                                 
                             }
                         }
                        break;

                    case 6:
                        System.out.print("Enter Product ID: ");
                        int removeId = scanner.nextInt();
                        System.out.print("Enter Quantity: ");
                        int quant = scanner.nextInt();
                        cart.removeFromCart(removeId, quant);
                        System.out.println("Product removed from cart.");
                        break;

                    case 7:
                        running = false;
                        break;

                    default:
                        System.out.println("Invalid choice, try with a valid option.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        }

        scanner.close();
    }
}
