package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.*;

public class MouseActionEg {
	
	public static void main(String[]args) throws Exception  {
		 
		//Chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\MouseActionEg.html");
        
	    Actions actions=new Actions(driver);
	    WebElement clickButton=driver.findElement(By.id("clickButton"));
	  //perform click 
	    actions.click().perform();
	    
	    Thread.sleep(2000);
	    //mouse over
	    WebElement hoverDiv=driver.findElement(By.id("hoverDiv"));
	    actions.moveToElement(hoverDiv).perform();
	    Thread.sleep(2000);
	  //perform double click
	    WebElement doubleClick=driver.findElement(By.id("doubleClickButton"));
	    actions.doubleClick(doubleClick).perform();
	    Thread.sleep(2000);
	    //right click
	    actions.contextClick(clickButton).perform();
	    //drag and drop
	    WebElement dragDiv=driver.findElement(By.id("dragDiv"));
	    WebElement dropArea=driver.findElement(By.id("dropArea"));
	    
	    actions.clickAndHold(dragDiv).moveToElement(dropArea).release().perform();
	    Thread.sleep(2000);
	    
	
	}
	}
