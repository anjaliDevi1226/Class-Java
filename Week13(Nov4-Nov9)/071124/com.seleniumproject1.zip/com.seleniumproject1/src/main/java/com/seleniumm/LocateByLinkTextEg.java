package com.seleniumm;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.*;

public class LocateByLinkTextEg {
	
	
	public static void main(String args[]) throws Exception{
		//set driver properties
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver=new ChromeDriver();
		
		//load webpage
		
		
		driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocateByLinkTextEg.html");
		
		//----wait until webpage loaded successfully
		//create webdriverwait
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		File screenshot1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
   		FileHandler.copy(screenshot1, new File("./screenshot1.png"));
		
		WebElement link1=driver.findElement(By.linkText("Visit Example"));
           link1.click();
           Thread.sleep(2000);
           System.out.println("Title : "+driver.getTitle());
           File screenshot2= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
   		FileHandler.copy(screenshot2, new File("./screenshot2.png"));
		
		Thread.sleep(2000);
		
		WebElement infolink=driver.findElement(By.partialLinkText("information"));
		
		
		infolink.click();
		Thread.sleep(2000);
		System.out.println("Next page Title : "+driver.getTitle());
		File screenshot3= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(screenshot3, new File("./screenshot3.png"));
		
		Thread.sleep(3000);
		
		driver.quit();
	}

}
