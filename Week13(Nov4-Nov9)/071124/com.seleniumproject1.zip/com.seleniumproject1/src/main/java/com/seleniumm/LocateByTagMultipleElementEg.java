package com.seleniumm;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByTagMultipleElementEg {
	
	public static void main(String[]args) throws Exception {
		//Chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocateByNameEg.html");
		//WebElement element=driver.findElement(By.tagName("input"));
		List<WebElement>elements=driver.findElements(By.tagName("input"));
		
		for(WebElement element : elements) {
			element.sendKeys("Some text here");
			System.out.println(element.getAttribute("name"));
		}
		
		Thread.sleep(2000);
		
		driver.quit();
	    
	    
	}

}
