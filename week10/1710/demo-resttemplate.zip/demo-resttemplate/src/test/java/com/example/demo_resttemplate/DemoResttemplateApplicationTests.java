package com.example.demo_resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;

@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {
	
	@Autowired
	private MockMvc mockmvc;

	@Test
	void contextLoads() throws Exception {
		mockmvc.perform(get("/redbus/6")) //sending GET request with url
		.andExpect(status().isOk()) //checking response Http Status code
		.andExpect(content().contentType(MediaType.APPLICATION_JSON)) //checking response content type
	//	.andExpect(content().contentType(MediaType.APPLICATION_XML));
		.andExpect(jsonPath("$.username").value("user2"))
		.andExpect(jsonPath("$.fromplace").value("CCC")) //checking content
		.andExpect(jsonPath("$.toplace").value("QQQUU"))
		.andExpect(jsonPath("$.price").value("100.09"));

	}
 
	
	@Test
	void testBookTicket() throws Exception{
		mockmvc.perform(post("/redbus")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
		"{\"username\":\"acv\","
		+"\"fromplace\":\"tuv\","
		+"\"toplace\":\"rtyu\","
		+"\"email\":\"987609o@gamil.com\","
		+"\"price\":100}"))
		.andExpect(status().isCreated())
				//).andExpect(status().is(201));
		.andDo(print())
		.andExpect(jsonPath("$.username").value("acv"));
			
	}
	
	@Test
	void testUpdateTicket() throws Exception{
		mockmvc.perform(put("/redbus/14")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
						"{"
						+ "\"fromplace\":\"fromplace11\","
						+ "\"toplace\":\"toplace11\","
						+ "email\":\"sd987@gamil.com\","
						+ "\"price\":9877}")
		).andExpect(status().isCreated());
				//).andExpect(status().is(201));
		//.andExpect(jsonPath("$.fromplace").value("fromplace11"))
		//.andExpect(jsonPath("$.toplace").value("toplace11"));
			
	}
	@Test
	void cancelTicket()throws Exception{
		mockmvc.perform(delete("/redbus/13"))
		
		.andExpect(status().isOk());
		
	}

}