package com.seleniumm;

import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertConfirmationPromtEg {
	
	public static void main(String[]args)   {
		try {
		//Chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
	    driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\AlertConfirmationPromtEg.html");
	    
	    WebElement alertButton =driver.findElement(By.xpath("//button[text()='Show Alert']"));
	    
	    alertButton.click();
	    
	    
	    Thread.sleep(2000);
	   Alert alert= driver.switchTo().alert();
	   
	   System.out.println(alert.getText());
	   alert.accept();
	   Thread.sleep(2000);
	   
	   driver.quit();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
