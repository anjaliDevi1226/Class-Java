package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HTMLFormEg {
	
	public static void main(String[]args) throws Exception  {

	// chrome driver path
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

				// Create an instance of driver
				WebDriver driver = new ChromeDriver();

				// Load web page under Test
				driver.get(
						"file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\KeyBoardAction.html");

				WebElement usernameField = driver.findElement(By.id("username"));
		 WebElement maleradio = driver.findElement(By.id("male"));
		 WebElement femaleradio = driver.findElement(By.id("female"));
		WebElement SubCheckbox = driver.findElement(By.id("subscribe"));
		WebElement dropdown = driver.findElement(By.id("dropdown"));
		 WebElement submitButton = driver.findElement(By.id("submitBtn"));
	 WebElement message = driver.findElement(By.id("message"));
		usernameField.sendKeys("Soemusername");
		 System.out.println("Username entred: "+usernameField.getAttribute("value"));
	 maleradio.click();
		 String str=maleradio.isSelected()?"Male":"Female";
		 System.out.println("Radio Slected :"+str);
		 SubCheckbox.click();
		 System.out.println("Subscribed : "+SubCheckbox.isSelected());
		   Select dropdownSelect = new Select(dropdown);
	  dropdownSelect.selectByVisibleText("Option 2");
		 dropdownSelect.getFirstSelectedOption().getText();
	  submitButton.sendKeys(Keys.ENTER);
		 Thread.sleep(5000);
		driver.quit();		
	}
	
}
