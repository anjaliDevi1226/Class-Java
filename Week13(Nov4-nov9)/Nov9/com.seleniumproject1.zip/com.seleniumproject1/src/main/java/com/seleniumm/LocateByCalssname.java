package com.seleniumm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

import org.openqa.selenium.*;

public class LocateByCalssname {
	
	
	public static void main(String args[]) throws Exception {
		
		
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
		
		//create driver instance
		WebDriver driver=new ChromeDriver();
		
		//load webpage
		
		driver.get("file:///C:\\Users\\Administrator\\eclipse-study\\com.seleniumproject1\\src\\main\\resources\\LocatedByClassname.html");
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(2));
		
		WebElement button=wait.until(ExpectedConditions.elementToBeClickable(By.className("button")));
		
		button.click();
		
		WebElement message=wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("message")));
		
		System.out.println("message displayed :"+message.getText());
		Thread.sleep(1000);
		driver.quit();
	}

}
