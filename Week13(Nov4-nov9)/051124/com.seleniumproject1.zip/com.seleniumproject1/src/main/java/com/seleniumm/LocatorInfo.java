package com.seleniumm;

public class LocatorInfo {

	
	//find elements -give list of element
	//find element -give first element
	//xpath stands for XML path
	//xpath->Absalute xpath & relative xpath
	//absalute xath: lengthy-> right click on the element->   ->copy xpath
	//XPath : //tagname[@Attributename="value "]
	
}
