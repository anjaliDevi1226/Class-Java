
 package com.example.demo_ticket.repository;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.example.demo_ticket.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface TicketRepository extends JpaRepository<Ticket,Integer> {
	

}
/*
package com.example.demo_ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo_ticket.model.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer> {
    // Custom query methods can be defined here if needed
}
*/