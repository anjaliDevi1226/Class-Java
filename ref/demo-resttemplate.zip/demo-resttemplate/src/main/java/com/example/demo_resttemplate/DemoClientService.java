package com.example.demo_resttemplate;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class DemoClientService {
	RestTemplate rClient = new RestTemplate();
	private final String BASE_URL ="http://localhost:8080/ticket/";
	
	public ResponseEntity<Ticket> getTickets(int ticketid){
		
		ResponseEntity<Ticket> reTicket =
				rClient.getForEntity(BASE_URL+ticketid,Ticket.class);
		return reTicket;
	}
	
	public ResponseEntity<Ticket> bookTicket(Ticket ticket) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("x-custom-hdr","abcd");
		HttpEntity<Ticket> request = new HttpEntity<Ticket>(ticket,httpHeaders);
		ResponseEntity<Ticket> reticket=
				rClient.postForEntity(BASE_URL+"book",request,Ticket.class);
		return reticket;
	}
	
	public ResponseEntity<Ticket> updateTicket(int ticketid,Ticket ticket) {
		/*rClient.put(BASE_URL+"update/"+ticketid, ticket);
		ResponseEntity<Ticket> rTicket = rClient.getForEntity(BASE_URL+ticketid,Ticket.class);*/
		HttpEntity<Ticket>request=new HttpEntity<>(ticket);
		ResponseEntity<Ticket> rTicket=rClient.exchange(BASE_URL+"update/"+ticketid,HttpMethod.PUT,request,Ticket.class);
		return rTicket;
	}
	
	 
	
}
