package com.seleniumEg_pomm;

public class info {

}
/*
 * 1. Basic  functinality of Homepage.java
 * 2. Basic functionality of AboutPage.java
 * 3.MainTestApp.java to navigate from homepage to Aboutpage and viceversa
 * 4. check working of above
 * 5.Basic functionality of ContactPage.jave
 * 6.Add More functionality to homepage
 * 7.AboutPage
 * 8.contact page
 * 
 * 
 * 
 */
