package com.seleniumm;

public class LocateByNameEg2 {
	
	public static void main(String args[]) {
		//set driver properties
		
		System.setProperty("webdriver.chrome.driver.", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
		
		//create driver instance
		//load webpage
		
		//----wait until webpage loaded successfully
		
		//locate username
		//enter text in username field 
		
		//locate age
		//enter age
		
		//locte button
		//click button
		
		//----wait for message to be visible
		
		//get updated message text
		
		
	}

}
